﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace H21_O2
{
    class Program
    {
        static List<int> l = new List<int>();
        static Mutex m = new Mutex();
   
        static void Main(string[] args)
        {
            const int ANTALL_TALL = 20;
            Random r = new Random();

            for (int i = 0; i < ANTALL_TALL; i++)
            {
                l.Add(r.Next(0, 100));
                Console.Write("{0} ", l[l.Count - 1]);
            }

            Console.WriteLine();

            ParameterizedThreadStart pts = new ParameterizedThreadStart(HT);
            Thread t1 = new Thread(pts);
            Thread t2 = new Thread(pts);
            Thread t3 = new Thread(pts);

            t1.Start(r);
            t2.Start(r);
            t3.Start(r);

            t1.Join();
            t2.Join();
            t3.Join();
            
            // Unødvendig - brukes kun for å teste programmet
            Console.WriteLine("Tall som er igjen:");
            for (int i = 0; i < l.Count; i++)
            {
                Console.Write("{0} ", l[i]);
            }
            Console.WriteLine();
            Console.ReadKey(true);
        }


        static void HT (object o)
        {
            Random r = o as Random;
            const int ANTALL_UTSKRIFT = 5;
            int tilfeldigPosisjon;

            int etTall;

            for (int i = 0; i < ANTALL_UTSKRIFT; i++)
            {
                Thread.Sleep(1000);
                // Kan bruke (for eksempel) Monitor klasse her i stedet
                m.WaitOne();
                tilfeldigPosisjon = r.Next(0, l.Count);
                etTall = l[tilfeldigPosisjon];
                l.RemoveAt(tilfeldigPosisjon);
                m.ReleaseMutex();
                Console.WriteLine("{0} tall fjernet: {1}", Thread.CurrentThread.ManagedThreadId, etTall);
            }
        }
    }
}
